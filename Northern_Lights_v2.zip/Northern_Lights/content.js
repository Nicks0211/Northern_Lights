// content.js — NEXUS AI Panel
// Guard contra múltiplas injeções
if (window.__nexusLoaded) {
  // Apenas reabre se já existir
  const existing = document.getElementById("nexus-panel");
  if (existing) existing.style.display = "flex";
} else {
  window.__nexusLoaded = true;
  initNexus();
}

function initNexus() {
  // ─── Estado ──────────────────────────────────────────────────────────────
  let history      = [];   // [{role, content}] — contexto enviado para a API
  let isLoading    = false;
  let settings     = { apiKey: "", systemPrompt: "", theme: "dark" };

  // ─── DOM: painel principal ───────────────────────────────────────────────
  const panel = createElement("div", "nexus-panel");
  panel.setAttribute("role", "dialog");
  panel.setAttribute("aria-label", "NEXUS AI");

  panel.innerHTML = `
    <div id="nexus-header">
      <span id="nexus-title">NEXUS <em>AI</em></span>
      <div id="nexus-header-actions">
        <button id="nexus-settings-btn" title="Configurações" aria-label="Configurações">⚙</button>
        <button id="nexus-clear-btn"    title="Limpar conversa" aria-label="Limpar">⊘</button>
        <button id="nexus-close-btn"    title="Fechar" aria-label="Fechar">✕</button>
      </div>
    </div>

    <div id="nexus-chat" role="log" aria-live="polite" aria-label="Conversa"></div>

    <div id="nexus-input-area">
      <textarea
        id="nexus-input"
        placeholder="Mensagem… (Enter para enviar)"
        rows="1"
        aria-label="Digite sua mensagem"
      ></textarea>
      <button id="nexus-send-btn" aria-label="Enviar">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <line x1="22" y1="2" x2="11" y2="13"></line>
          <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
        </svg>
      </button>
    </div>

    <!-- Painel de configurações (oculto por padrão) -->
    <div id="nexus-settings-panel" hidden>
      <h3>Configurações</h3>
      <label>
        API Key Anthropic
        <input type="password" id="nexus-api-key" placeholder="sk-ant-…" autocomplete="off" />
      </label>
      <label>
        Prompt do sistema
        <textarea id="nexus-system-prompt" rows="3"></textarea>
      </label>
      <div id="nexus-settings-actions">
        <button id="nexus-save-settings">Salvar</button>
        <button id="nexus-cancel-settings">Cancelar</button>
      </div>
    </div>
  `;

  document.body.appendChild(panel);

  // ─── Referências ─────────────────────────────────────────────────────────
  const chat            = panel.querySelector("#nexus-chat");
  const input           = panel.querySelector("#nexus-input");
  const sendBtn         = panel.querySelector("#nexus-send-btn");
  const closeBtn        = panel.querySelector("#nexus-close-btn");
  const clearBtn        = panel.querySelector("#nexus-clear-btn");
  const settingsBtn     = panel.querySelector("#nexus-settings-btn");
  const settingsPanel   = panel.querySelector("#nexus-settings-panel");
  const apiKeyInput     = panel.querySelector("#nexus-api-key");
  const systemPromptTA  = panel.querySelector("#nexus-system-prompt");
  const saveSettingsBtn = panel.querySelector("#nexus-save-settings");
  const cancelSettingsBtn = panel.querySelector("#nexus-cancel-settings");

  // ─── Carrega configurações salvas ────────────────────────────────────────
  chrome.storage.local.get(["nexus_settings", "nexus_history"], (result) => {
    if (result.nexus_settings) {
      settings = result.nexus_settings;
    }
    if (result.nexus_history) {
      history = result.nexus_history;
      renderHistory();
    } else {
      addMessageToDOM("NEXUS conectado. Como posso ajudar?", "ai");
    }
  });

  // ─── Envio de mensagem ───────────────────────────────────────────────────
  async function sendMessage() {
    const text = input.value.trim();
    if (!text || isLoading) return;

    input.value = "";
    autoResizeTextarea(input);
    addMessageToDOM(text, "user");
    history.push({ role: "user", content: text });

    const typingEl = showTypingIndicator();
    isLoading = true;
    sendBtn.disabled = true;

    chrome.runtime.sendMessage({
      action: "call_claude",
      payload: {
        apiKey:       settings.apiKey,
        systemPrompt: settings.systemPrompt,
        history:      history.slice(0, -1), // envia histórico sem a mensagem atual (já incluída no payload)
        userMessage:  text
      }
    }, (response) => {
      typingEl.remove();
      isLoading = false;
      sendBtn.disabled = false;

      if (chrome.runtime.lastError) {
        addMessageToDOM("Erro de comunicação com o background.", "error");
        return;
      }

      if (response.ok) {
        addMessageToDOM(response.reply, "ai");
        history.push({ role: "assistant", content: response.reply });
        persistHistory();
      } else {
        addMessageToDOM(`⚠ ${response.error}`, "error");
        // Remove a mensagem do usuário do histórico se a API falhou
        history.pop();
      }

      input.focus();
    });
  }

  // ─── Eventos de input ────────────────────────────────────────────────────
  sendBtn.addEventListener("click", sendMessage);

  input.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  });

  input.addEventListener("input", () => autoResizeTextarea(input));

  // ─── Controles do painel ─────────────────────────────────────────────────
  closeBtn.addEventListener("click", () => {
    panel.style.display = "none";
  });

  clearBtn.addEventListener("click", () => {
    history = [];
    chat.innerHTML = "";
    chrome.storage.local.remove("nexus_history");
    addMessageToDOM("Conversa reiniciada.", "ai");
  });

  // ─── Settings ────────────────────────────────────────────────────────────
  settingsBtn.addEventListener("click", () => {
    const isOpen = !settingsPanel.hidden;
    settingsPanel.hidden = isOpen;
    if (!isOpen) {
      apiKeyInput.value      = settings.apiKey;
      systemPromptTA.value   = settings.systemPrompt;
    }
  });

  saveSettingsBtn.addEventListener("click", () => {
    settings.apiKey       = apiKeyInput.value.trim();
    settings.systemPrompt = systemPromptTA.value.trim();
    chrome.storage.local.set({ nexus_settings: settings }, () => {
      settingsPanel.hidden = true;
      addMessageToDOM("✓ Configurações salvas.", "ai");
    });
  });

  cancelSettingsBtn.addEventListener("click", () => {
    settingsPanel.hidden = true;
  });

  // ─── Toggle por mensagem do background ───────────────────────────────────
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.action === "toggle_nexus") {
      const isHidden = panel.style.display === "none" || panel.style.display === "";
      panel.style.display = isHidden ? "flex" : "none";
      if (isHidden) input.focus();
    }
  });

  // ─── Drag — limitado aos bounds da viewport ──────────────────────────────
  let dragging = false;
  let startX, startY, startLeft, startTop;

  const header = panel.querySelector("#nexus-header");

  header.addEventListener("mousedown", (e) => {
    // Não inicia drag se clicou em um botão
    if (e.target.tagName === "BUTTON") return;
    dragging = true;
    startX = e.clientX;
    startY = e.clientY;
    const rect = panel.getBoundingClientRect();
    startLeft = rect.left;
    startTop  = rect.top;
    e.preventDefault();
  });

  document.addEventListener("mousemove", (e) => {
    if (!dragging) return;

    const dx = e.clientX - startX;
    const dy = e.clientY - startY;

    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const pw = panel.offsetWidth;
    const ph = panel.offsetHeight;

    // Limita aos bounds da janela com margem de 8px
    const left = Math.min(Math.max(startLeft + dx, 8), vw - pw - 8);
    const top  = Math.min(Math.max(startTop  + dy, 8), vh - ph - 8);

    panel.style.left  = `${left}px`;
    panel.style.top   = `${top}px`;
    panel.style.right = "auto";
  });

  document.addEventListener("mouseup", () => { dragging = false; });

  // ─── Helpers ─────────────────────────────────────────────────────────────

  function addMessageToDOM(text, type) {
    const msg = createElement("div", `nexus-msg nexus-msg--${type}`);
    // Usa textContent para evitar XSS
    msg.textContent = text;
    chat.appendChild(msg);
    chat.scrollTop = chat.scrollHeight;
    return msg;
  }

  function showTypingIndicator() {
    const el = createElement("div", "nexus-msg nexus-msg--ai nexus-typing");
    el.innerHTML = `<span></span><span></span><span></span>`;
    chat.appendChild(el);
    chat.scrollTop = chat.scrollHeight;
    return el;
  }

  function renderHistory() {
    chat.innerHTML = "";
    for (const entry of history) {
      const type = entry.role === "user" ? "user" : "ai";
      addMessageToDOM(entry.content, type);
    }
  }

  function persistHistory() {
    // Persiste apenas os últimos 40 itens para não lotar o storage
    const toSave = history.slice(-40);
    chrome.storage.local.set({ nexus_history: toSave });
  }

  function autoResizeTextarea(el) {
    el.style.height = "auto";
    el.style.height = Math.min(el.scrollHeight, 120) + "px";
  }

  function createElement(tag, className) {
    const el = document.createElement(tag);
    if (className) el.className = className;
    return el;
  }
}
