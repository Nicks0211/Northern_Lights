// background.js — NEXUS AI Service Worker
// Responsável por: menu de contexto, relay de mensagens para a API Claude,
// e persistência de configurações via chrome.storage.

const CLAUDE_API_URL = "https://api.anthropic.com/v1/messages";
const CLAUDE_MODEL   = "claude-opus-4-5";
const MAX_TOKENS     = 1024;
const MAX_HISTORY    = 20; // máximo de pares user/assistant mantidos

// ─── Context Menu ────────────────────────────────────────────────────────────

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "open-nexus",
    title: "Abrir NEXUS AI",
    contexts: ["all"]
  });

  // Configurações padrão na primeira instalação
  chrome.storage.local.get("nexus_settings", (result) => {
    if (!result.nexus_settings) {
      chrome.storage.local.set({
        nexus_settings: {
          apiKey: "",
          systemPrompt: "Você é o NEXUS, um assistente de IA útil, direto e inteligente. Responda sempre em português.",
          theme: "dark"
        }
      });
    }
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "open-nexus" && tab?.id) {
    chrome.tabs.sendMessage(tab.id, { action: "toggle_nexus" }).catch(() => {
      // Content script pode não ter carregado ainda — injeta sob demanda
      chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] })
        .then(() => chrome.scripting.insertCSS({ target: { tabId: tab.id }, files: ["content.css"] }))
        .then(() => chrome.tabs.sendMessage(tab.id, { action: "toggle_nexus" }))
        .catch(console.error);
    });
  }
});

// ─── Relay de mensagens para a API Claude ────────────────────────────────────
// O content script NÃO pode chamar a API diretamente por restrições de CSP.
// Toda comunicação com a API passa por aqui.

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.action === "call_claude") {
    handleClaudeRequest(message.payload)
      .then((reply) => sendResponse({ ok: true, reply }))
      .catch((err)  => sendResponse({ ok: false, error: err.message }));

    return true; // mantém o canal aberto para resposta assíncrona
  }
});

async function handleClaudeRequest({ apiKey, systemPrompt, history, userMessage }) {
  if (!apiKey?.trim()) {
    throw new Error("API key não configurada. Clique em ⚙ para configurar.");
  }

  // Monta histórico respeitando o limite de contexto
  const trimmed = history.slice(-MAX_HISTORY);
  const messages = [
    ...trimmed,
    { role: "user", content: userMessage }
  ];

  const response = await fetch(CLAUDE_API_URL, {
    method: "POST",
    headers: {
      "Content-Type":            "application/json",
      "x-api-key":               apiKey,
      "anthropic-version":       "2023-06-01",
      "anthropic-dangerous-allow-browser-access": "true"
    },
    body: JSON.stringify({
      model:      CLAUDE_MODEL,
      max_tokens: MAX_TOKENS,
      system:     systemPrompt,
      messages
    })
  });

  if (!response.ok) {
    const body = await response.json().catch(() => ({}));
    const msg = body?.error?.message ?? `Erro HTTP ${response.status}`;
    throw new Error(msg);
  }

  const data = await response.json();
  const reply = data?.content?.[0]?.text;

  if (!reply) throw new Error("Resposta inesperada da API.");

  return reply;
}
