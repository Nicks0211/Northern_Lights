/**
 * Northern Lights — Popup Controller
 * Gerencia UI, chat com IA, ferramentas e automações
 *
 * FIXES aplicados:
 *  [1] E object inicializado DENTRO do DOMContentLoaded (sem risco de null)
 *  [2] switch-case com const → cada case envolto em {} (strict mode safe)
 *  [3] SVG gradient IDs únicos por avatar (sem IDs duplicados no DOM)
 *  [4] linksModal abre/fecha com aria-modal controlado via JS
 *  [5] Null-guards extras em operações assíncronas
 */
'use strict';

// ══════════════════════════════════════════════════════════════════
// Estado global
// ══════════════════════════════════════════════════════════════════
const S = {
  apiKey:    '',
  model:     'claude-sonnet-4-6',
  sysPrompt: '',
  history:   [],
  busy:      false,
  zoom:      100,
};

// Contador para IDs únicos de gradiente SVG
let _avatarSeq = 0;

// ══════════════════════════════════════════════════════════════════
// Bootstrap — E é populado dentro do DOMContentLoaded [FIX 1]
// ══════════════════════════════════════════════════════════════════
document.addEventListener('DOMContentLoaded', async () => {
  const $ = (id) => document.getElementById(id);

  // Todos os seletores inicializados após o DOM estar pronto
  const E = {
    // Tabs / Panels
    tabs:   document.querySelectorAll('.tab'),
    panels: document.querySelectorAll('.panel'),
    // Chat
    messages:     $('chatMessages'),
    input:        $('chatInput'),
    sendBtn:      $('sendBtn'),
    charCount:    $('charCount'),
    modelBadge:   $('modelBadge'),
    quickActions: document.querySelectorAll('.chip'),
    // Settings
    settingsBtn:   $('settingsBtn'),
    settingsPanel: $('settingsPanel'),
    closeSettings: $('closeSettings'),
    apiKeyInput:   $('apiKeyInput'),
    toggleApiVis:  $('toggleApiVis'),
    saveApiKey:    $('saveApiKey'),
    apiStatus:     $('apiStatus'),
    modelSelect:   $('modelSelect'),
    sysPrompt:     $('sysPrompt'),
    clearHistory:  $('clearHistory'),
    resetAll:      $('resetAll'),
    // Ferramentas
    toggleUnlocker:  $('toggleUnlocker'),
    searchText:      $('searchText'),
    doSearch:        $('doSearch'),
    clearSearch:     $('clearSearch'),
    calcReading:     $('calcReading'),
    readingResult:   $('readingResult'),
    extractLinks:    $('extractLinks'),
    copyPageText:    $('copyPageText'),
    toggleFocus:     $('toggleFocus'),
    linksModal:      $('linksModal'),
    linksBody:       $('linksBody'),
    closeLinksModal: $('closeLinksModal'),
    // Automações
    toggleDark:       $('toggleDark'),
    readerMode:       $('readerMode'),
    toggleAutoScroll: $('toggleAutoScroll'),
    scrollSpeed:      $('scrollSpeed'),
    scrollSpeedVal:   $('scrollSpeedVal'),
    muteVideos:       $('muteVideos'),
    toggleImages:     $('toggleImages'),
    zoomIn:           $('zoomIn'),
    zoomOut:          $('zoomOut'),
    zoomReset:        $('zoomReset'),
    zoomVal:          $('zoomVal'),
    // Toast
    toast: $('toast'),
  };

  // ── Inicialização ──────────────────────────────────────────────
  await loadState(E);
  bindTabs(E);
  bindChat(E);
  bindSettings(E);
  bindTools(E);
  bindAutomations(E);
  await checkPending(E);
  appendWelcome(E);
});

// ══════════════════════════════════════════════════════════════════
// Persistência
// ══════════════════════════════════════════════════════════════════
async function loadState(E) {
  const d = await chrome.storage.sync.get([
    'apiKey', 'model', 'sysPrompt', 'history', 'unlockerEnabled', 'darkMode',
  ]);

  S.apiKey    = d.apiKey    ?? '';
  S.model     = d.model     ?? 'claude-sonnet-4-6';
  S.sysPrompt = d.sysPrompt ?? defaultSystemPrompt();
  S.history   = (d.history  ?? []).slice(-40);

  E.apiKeyInput.value      = S.apiKey ? '●'.repeat(16) : '';
  E.modelSelect.value      = S.model;
  E.sysPrompt.value        = S.sysPrompt;
  E.toggleUnlocker.checked = !!d.unlockerEnabled;
  E.toggleDark.checked     = !!d.darkMode;

  updateModelBadge(E);
}

function defaultSystemPrompt() {
  return `Você é o Northern Lights, assistente de IA integrado ao navegador.
Seja conciso, útil e amigável. Responda sempre no idioma do usuário.
Pode resumir páginas, traduzir, explicar e ajudar com qualquer tarefa.`;
}

async function save(obj) {
  await chrome.storage.sync.set(obj);
}

// ══════════════════════════════════════════════════════════════════
// Tabs
// ══════════════════════════════════════════════════════════════════
function bindTabs(E) {
  E.tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      E.tabs.forEach(t   => { t.classList.remove('tab--active'); t.setAttribute('aria-selected', 'false'); });
      E.panels.forEach(p => p.classList.remove('panel--active'));
      tab.classList.add('tab--active');
      tab.setAttribute('aria-selected', 'true');
      const panel = document.getElementById(`panel-${tab.dataset.tab}`);
      panel?.classList.add('panel--active');
    });
  });
}

function switchTab(name) {
  document.querySelector(`.tab[data-tab="${name}"]`)?.click();
}

// ══════════════════════════════════════════════════════════════════
// Chat
// ══════════════════════════════════════════════════════════════════
function bindChat(E) {
  // Auto-resize do textarea
  E.input.addEventListener('input', () => {
    E.input.style.height = 'auto';
    E.input.style.height = Math.min(E.input.scrollHeight, 80) + 'px';
    const n = E.input.value.length;
    E.charCount.textContent = `${n} / 4000`;
    E.charCount.style.color = n > 3600 ? '#ff5566' : '';
  });

  // Enter envia, Shift+Enter quebra linha
  E.input.addEventListener('keydown', e => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(E); }
  });

  E.sendBtn.addEventListener('click', () => send(E));

  // Quick action chips
  E.quickActions.forEach(btn => {
    btn.addEventListener('click', () => quickAction(btn.dataset.qa, E));
  });
}

function appendWelcome(E) {
  if (E.messages.children.length === 0) {
    addMsg('assistant', '👋 Olá! Sou o **Northern Lights**, seu assistente de IA. Pergunte qualquer coisa, ou use as ações rápidas abaixo!', E);
  }
}

async function send(E) {
  const text = E.input.value.trim();
  if (!text || S.busy) return;

  if (!S.apiKey) {
    toast('🔑 Configure sua API Key nas configurações', 'err', E);
    openSettings(E);
    return;
  }

  addMsg('user', text, E);
  S.history.push({ role: 'user', content: text });
  E.input.value = '';
  E.input.style.height = 'auto';
  E.charCount.textContent = '0 / 4000';

  await aiRequest(E);
}

async function quickAction(action, E) {
  if (S.busy) return;
  if (!S.apiKey) { toast('🔑 Configure sua API Key', 'err', E); openSettings(E); return; }

  const tab = await getActiveTab();
  if (!tab?.id) return;

  // FIX [2]: variáveis declaradas antes do switch para evitar lexical scope issues
  let userMsg     = '';
  let pageContext = '';
  let sel         = '';

  try {
    const info = await chrome.tabs.sendMessage(tab.id, { action: 'GET_PAGE_INFO' });

    // FIX [2]: cada case envolto em {} — const seguro em strict mode
    switch (action) {
      case 'summarize': {
        userMsg     = '📄 Resuma o conteúdo principal desta página de forma clara e concisa.';
        pageContext = `\n\n[PÁGINA: ${info.title}]\n${info.text.substring(0, 4000)}`;
        break;
      }
      case 'translate': {
        sel         = info.selectedText || info.text.substring(0, 2000);
        userMsg     = '🌐 Traduza o texto abaixo para português (Brasil):';
        pageContext = `\n\n${sel}`;
        break;
      }
      case 'explain': {
        sel         = info.selectedText || info.text.substring(0, 2000);
        userMsg     = '💡 Explique o seguinte trecho de forma simples e didática:';
        pageContext = `\n\n${sel}`;
        break;
      }
      default:
        return;
    }
  } catch (err) {
    const msg = String(err?.message ?? '');
    if (msg.includes('Cannot access') || msg.includes('chrome://') || msg.includes('extension')) {
      toast('⚠️ Esta página não pode ser acessada pela extensão', 'err', E);
    } else {
      toast('⚠️ Não foi possível acessar o conteúdo desta página', 'err', E);
    }
    return;
  }

  const fullMsg = userMsg + pageContext;
  addMsg('user', userMsg, E);
  S.history.push({ role: 'user', content: fullMsg });
  switchTab('chat');
  await aiRequest(E);
}

async function aiRequest(E) {
  S.busy = true;
  E.sendBtn.disabled = true;

  const loadingId = addMsg('loading', '', E);

  try {
    const res = await chrome.runtime.sendMessage({
      action:       'AI_REQUEST',
      apiKey:       S.apiKey,
      model:        S.model,
      systemPrompt: S.sysPrompt,
      messages:     S.history,
    });

    removeMsg(loadingId);

    if (!res?.ok) throw new Error(res?.error ?? 'Resposta inválida da API');

    const reply = res.result;
    addMsg('assistant', reply, E);
    S.history.push({ role: 'assistant', content: reply });
    await save({ history: S.history.slice(-40) });

  } catch (err) {
    removeMsg(loadingId);
    addMsg('assistant', `❌ Erro: ${err.message}`, E);
    console.error('[NL] AI error:', err);
  } finally {
    S.busy = false;
    E.sendBtn.disabled = false;
    E.input.focus();
  }
}

// ══════════════════════════════════════════════════════════════════
// Renderização de mensagens
// ══════════════════════════════════════════════════════════════════
let _msgId = 0;

function addMsg(role, text, E) {
  const id  = `msg-${++_msgId}`;
  const div = document.createElement('div');
  div.id    = id;

  if (role === 'loading') {
    div.className   = 'msg msg--assistant msg--loading';
    div.innerHTML   = `
      <div class="msg__avatar">${avatarAI()}</div>
      <div class="msg__body">
        <span class="dot"></span>
        <span class="dot"></span>
        <span class="dot"></span>
      </div>`;
  } else {
    div.className = `msg msg--${role}`;
    div.innerHTML = `
      <div class="msg__avatar">${role === 'assistant' ? avatarAI() : avatarUser()}</div>
      <div class="msg__body">${renderMarkdown(text)}</div>`;
  }

  E.messages.appendChild(div);
  E.messages.scrollTo({ top: E.messages.scrollHeight, behavior: 'smooth' });
  return id;
}

function removeMsg(id) {
  document.getElementById(id)?.remove();
}

/**
 * FIX [3]: IDs de gradiente únicos por chamada — evita colisões no DOM SVG
 */
function avatarAI() {
  const uid = ++_avatarSeq;
  return `<svg viewBox="0 0 26 26" fill="none" width="26" height="26" aria-hidden="true">
    <circle cx="13" cy="13" r="12" fill="url(#nl-avA-${uid})" opacity=".18"/>
    <path d="M4 18 Q8 6 13 10 Q18 14 22 4"  stroke="url(#nl-avA-${uid})" stroke-width="2.2" stroke-linecap="round" fill="none"/>
    <path d="M3 21 Q9 14 13 16 Q17 18 23 8" stroke="url(#nl-avB-${uid})" stroke-width="1.4" stroke-linecap="round" fill="none" opacity=".65"/>
    <defs>
      <linearGradient id="nl-avA-${uid}" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%"   stop-color="#00ff88"/>
        <stop offset="100%" stop-color="#00ccff"/>
      </linearGradient>
      <linearGradient id="nl-avB-${uid}" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%"   stop-color="#8855ff"/>
        <stop offset="100%" stop-color="#00ff88"/>
      </linearGradient>
    </defs>
  </svg>`;
}

function avatarUser() {
  return `<svg viewBox="0 0 26 26" fill="none" width="26" height="26" aria-hidden="true">
    <circle cx="13" cy="13" r="12" fill="rgba(0,204,255,.12)" stroke="rgba(0,204,255,.25)" stroke-width="1"/>
    <circle cx="13" cy="10" r="4"  fill="rgba(0,204,255,.5)"/>
    <path d="M5 22 Q5 17 13 17 Q21 17 21 22" fill="rgba(0,204,255,.35)"/>
  </svg>`;
}

/**
 * Mini renderizador Markdown seguro — sem dependências externas
 * Suporta: **bold**, *italic*, `code`, ```blocos```, > quote, listas
 */
function renderMarkdown(text) {
  if (!text) return '';

  // 1. Escapa HTML (anti-XSS)
  let html = text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');

  // 2. Code blocks
  html = html.replace(/```[\w]*\n?([\s\S]*?)```/g, (_, c) =>
    `<pre style="background:rgba(0,0,0,.4);padding:8px;border-radius:6px;overflow-x:auto;font-size:10.5px;margin:4px 0;"><code>${c.trim()}</code></pre>`
  );

  // 3. Inline code
  html = html.replace(/`([^`]+)`/g, '<code>$1</code>');

  // 4. Bold
  html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');

  // 5. Italic (não conflita com bold)
  html = html.replace(/\*(?!\*)(.+?)(?<!\*)\*/g, '<em>$1</em>');

  // 6. Listas — agrupa <li> consecutivos em um único <ul>
  html = html.replace(/^[\s]*[-•]\s(.+)$/gm, '<li>$1</li>');
  html = html.replace(/(<li>.*<\/li>)(\n<li>.*<\/li>)*/g, (block) =>
    `<ul style="padding-left:16px;margin:4px 0;">${block}</ul>`
  );

  // 7. Blockquote
  html = html.replace(/^&gt;\s(.+)$/gm,
    '<blockquote style="border-left:2px solid var(--aurora-b);padding-left:8px;color:var(--c-muted);margin:4px 0;">$1</blockquote>'
  );

  // 8. Quebras de linha
  html = html.replace(/\n/g, '<br>');

  return html;
}

// ══════════════════════════════════════════════════════════════════
// Settings
// ══════════════════════════════════════════════════════════════════
function bindSettings(E) {
  E.settingsBtn.addEventListener('click',   () => openSettings(E));
  E.closeSettings.addEventListener('click', () => closeSettings(E));

  // Mostrar / ocultar API key
  E.toggleApiVis.addEventListener('click', async () => {
    const isPass = E.apiKeyInput.type === 'password';
    E.apiKeyInput.type = isPass ? 'text' : 'password';
    if (isPass) {
      // Garante que a chave real está carregada ao revelar
      if (!S.apiKey) {
        const d = await chrome.storage.sync.get(['apiKey']);
        S.apiKey = d.apiKey ?? '';
      }
      E.apiKeyInput.value = S.apiKey || '';
    } else {
      E.apiKeyInput.value = S.apiKey ? '●'.repeat(16) : '';
    }
    E.toggleApiVis.textContent = isPass ? '🙈' : '👁';
  });

  // Salvar e validar API key
  E.saveApiKey.addEventListener('click', async () => {
    const key = E.apiKeyInput.value.trim();

    if (!key || key.includes('●')) {
      setApiStatus('⚠️ Insira uma chave válida', 'err', E);
      return;
    }
    if (!key.startsWith('sk-ant-')) {
      setApiStatus('❌ Formato inválido — deve começar com sk-ant-', 'err', E);
      return;
    }

    E.saveApiKey.textContent = '⏳ Validando…';
    E.saveApiKey.disabled    = true;

    const valid = await validateApiKey(key);

    E.saveApiKey.textContent = 'Salvar e Validar';
    E.saveApiKey.disabled    = false;

    if (valid) {
      S.apiKey = key;
      await save({ apiKey: key });
      setApiStatus('✅ API Key válida e salva!', 'ok', E);
      E.apiKeyInput.type  = 'password';
      E.apiKeyInput.value = '●'.repeat(16);
    } else {
      setApiStatus('❌ Chave inválida ou sem créditos', 'err', E);
    }
  });

  // Modelo
  E.modelSelect.addEventListener('change', async () => {
    S.model = E.modelSelect.value;
    await save({ model: S.model });
    updateModelBadge(E);
    toast('✅ Modelo atualizado', 'ok', E);
  });

  // System prompt
  E.sysPrompt.addEventListener('change', async () => {
    S.sysPrompt = E.sysPrompt.value;
    await save({ sysPrompt: S.sysPrompt });
    toast('✅ Personalidade salva', 'ok', E);
  });

  // Limpar histórico
  E.clearHistory.addEventListener('click', async () => {
    if (!confirm('Limpar todo o histórico de chat?')) return;
    S.history = [];
    E.messages.innerHTML = '';
    await save({ history: [] });
    appendWelcome(E);
    toast('🗑️ Histórico apagado', 'ok', E);
  });

  // Reset total
  E.resetAll.addEventListener('click', async () => {
    if (!confirm('Resetar TODAS as configurações? Esta ação não pode ser desfeita.')) return;
    await chrome.storage.sync.clear();
    toast('⚠️ Resetado. Reabra a extensão.', 'ok', E);
    setTimeout(() => window.close(), 1400);
  });
}

function openSettings(E) {
  E.settingsPanel.setAttribute('data-open', 'true');
  E.settingsPanel.setAttribute('aria-hidden', 'false');
}

function closeSettings(E) {
  E.settingsPanel.setAttribute('data-open', 'false');
  E.settingsPanel.setAttribute('aria-hidden', 'true');
}

function setApiStatus(msg, type, E) {
  E.apiStatus.textContent = msg;
  E.apiStatus.className   = `api-status api-status--${type}`;
}

function updateModelBadge(E) {
  const labels = {
    'claude-sonnet-4-6':         'Sonnet 4.6',
    'claude-opus-4-6':           'Opus 4.6',
    'claude-haiku-4-5-20251001': 'Haiku 4.5',
  };
  E.modelBadge.textContent = `Claude ${labels[S.model] ?? S.model}`;
}

async function validateApiKey(key) {
  try {
    const res = await chrome.runtime.sendMessage({
      action:   'AI_REQUEST',
      apiKey:   key,
      model:    'claude-haiku-4-5-20251001',
      messages: [{ role: 'user', content: 'ping' }],
    });
    return res?.ok === true;
  } catch {
    return false;
  }
}

// ══════════════════════════════════════════════════════════════════
// Ferramentas
// ══════════════════════════════════════════════════════════════════
function bindTools(E) {

  // ── Desbloqueador ──────────────────────────────────────────────
  E.toggleUnlocker.addEventListener('change', async () => {
    const enabled = E.toggleUnlocker.checked;
    await save({ unlockerEnabled: enabled });
    await sendToContent(enabled ? 'ENABLE_UNLOCKER' : 'DISABLE_UNLOCKER');
    toast(enabled ? '🔓 Desbloqueador ativado!' : '🔒 Desbloqueador desativado', 'ok', E);
  });

  // ── Buscar e destacar ──────────────────────────────────────────
  E.doSearch.addEventListener('click', async () => {
    const q = E.searchText.value.trim();
    if (!q) return;
    await sendToContent('HIGHLIGHT_TEXT', { text: q });
    toast(`🔍 "${q}" destacado`, 'ok', E);
  });

  E.searchText.addEventListener('keydown', e => {
    if (e.key === 'Enter') E.doSearch.click();
  });

  E.clearSearch.addEventListener('click', async () => {
    E.searchText.value = '';
    await sendToContent('CLEAR_HIGHLIGHTS');
    toast('✕ Destaques removidos', 'ok', E);
  });

  // ── Tempo de leitura ───────────────────────────────────────────
  E.calcReading.addEventListener('click', async () => {
    try {
      const tab = await getActiveTab();
      if (!tab?.id) { E.readingResult.textContent = 'Nenhuma aba ativa'; return; }
      const info = await chrome.tabs.sendMessage(tab.id, { action: 'GET_PAGE_INFO' });
      const mins = Math.ceil((info.wordCount ?? 0) / 230);
      E.readingResult.textContent = `~${mins} min · ${(info.wordCount ?? 0).toLocaleString('pt-BR')} palavras`;
    } catch {
      E.readingResult.textContent = 'Não disponível nesta página';
    }
  });

  // ── Extrair links ──────────────────────────────────────────────
  E.extractLinks.addEventListener('click', async () => {
    const tab = await getActiveTab();
    if (!tab?.id) return;

    try {
      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => [...document.querySelectorAll('a[href]')]
          .filter(a => a.href.startsWith('http'))
          .slice(0, 80)
          .map(a => ({
            href: a.href,
            text: (a.textContent ?? a.href).trim().substring(0, 60),
          })),
      });

      const links = results?.[0]?.result ?? [];
      if (!links.length) { toast('Nenhum link encontrado', 'ok', E); return; }

      E.linksBody.innerHTML = links.map(l => `
        <div class="link-item" data-href="${escapeHtml(l.href)}" role="link" tabindex="0">
          <strong>${escapeHtml(l.text || l.href)}</strong>
          ${escapeHtml(l.href)}
        </div>
      `).join('');

      E.linksBody.querySelectorAll('.link-item').forEach(item => {
        item.addEventListener('click',   () => chrome.tabs.create({ url: item.dataset.href }));
        item.addEventListener('keydown', ev => { if (ev.key === 'Enter') item.click(); });
      });

      // FIX [4]: define aria-modal apenas ao abrir
      openModal(E.linksModal);

    } catch {
      toast('⚠️ Erro ao extrair links', 'err', E);
    }
  });

  E.closeLinksModal.addEventListener('click', () => closeModal(E.linksModal));

  // Fecha modal ao clicar no backdrop
  E.linksModal.addEventListener('click', e => {
    if (e.target === E.linksModal) closeModal(E.linksModal);
  });

  // ── Copiar texto da página ─────────────────────────────────────
  E.copyPageText.addEventListener('click', async () => {
    const tab = await getActiveTab();
    if (!tab?.id) return;
    try {
      const { text } = await chrome.tabs.sendMessage(tab.id, { action: 'GET_PAGE_TEXT' });
      await navigator.clipboard.writeText(text ?? '');
      toast('📋 Texto copiado!', 'ok', E);
    } catch {
      toast('⚠️ Erro ao copiar texto', 'err', E);
    }
  });

  // ── Modo foco ──────────────────────────────────────────────────
  E.toggleFocus.addEventListener('change', async () => {
    const on  = E.toggleFocus.checked;
    const tab = await getActiveTab();
    if (!tab?.id) return;
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: (enabled) => {
        const ID = 'nl-focus-style';
        if (enabled) {
          if (document.getElementById(ID)) return;
          const s = document.createElement('style');
          s.id = ID;
          s.textContent = `
            *:focus        { outline: 2px solid #00ff88 !important; outline-offset: 2px !important; }
            *:focus-within { box-shadow: 0 0 0 3px rgba(0,255,136,.2) !important; }
          `;
          document.head.appendChild(s);
        } else {
          document.getElementById(ID)?.remove();
        }
      },
      args: [on],
    });
    toast(on ? '🎯 Modo Foco ativado' : '🎯 Modo Foco desativado', 'ok', E);
  });
}

// ══════════════════════════════════════════════════════════════════
// Automações
// ══════════════════════════════════════════════════════════════════
function bindAutomations(E) {

  // ── Dark mode universal ────────────────────────────────────────
  E.toggleDark.addEventListener('change', async () => {
    const on  = E.toggleDark.checked;
    await save({ darkMode: on });
    const tab = await getActiveTab();
    if (!tab?.id) return;
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: (enabled) => {
        const ID = 'nl-dark-mode';
        if (enabled) {
          if (document.getElementById(ID)) return;
          const s = document.createElement('style');
          s.id = ID;
          s.textContent = `
            html { filter: invert(1) hue-rotate(180deg) !important; }
            img, video, canvas, svg, picture, iframe {
              filter: invert(1) hue-rotate(180deg) !important;
            }
          `;
          document.documentElement.appendChild(s);
        } else {
          document.getElementById(ID)?.remove();
        }
      },
      args: [on],
    });
    toast(on ? '🌙 Dark mode ativado' : '☀️ Dark mode desativado', 'ok', E);
  });

  // ── Modo leitura ───────────────────────────────────────────────
  E.readerMode.addEventListener('click', async () => {
    const tab = await getActiveTab();
    if (!tab?.id) return;
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        const ID = 'nl-reader-mode';
        if (document.getElementById(ID)) {
          document.getElementById(ID).remove();
          return;
        }
        const s = document.createElement('style');
        s.id = ID;
        s.textContent = `
          body > *:not(script):not(style) { opacity: 0.05 !important; pointer-events: none !important; }
          article, main, [role="main"], .content, #content, .post, .entry-content {
            opacity: 1 !important;
            pointer-events: auto !important;
            max-width: 720px !important;
            margin: 40px auto !important;
            padding: 24px !important;
            font-family: Georgia, serif !important;
            font-size: 18px !important;
            line-height: 1.75 !important;
          }
        `;
        document.head.appendChild(s);
      },
    });
    toast('📖 Modo leitura alternado', 'ok', E);
  });

  // ── Auto scroll ────────────────────────────────────────────────
  E.scrollSpeed.addEventListener('input', () => {
    E.scrollSpeedVal.textContent = E.scrollSpeed.value;
  });

  E.toggleAutoScroll.addEventListener('change', async () => {
    const on  = E.toggleAutoScroll.checked;
    const spd = parseInt(E.scrollSpeed.value, 10);
    const tab = await getActiveTab();
    if (!tab?.id) return;
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: (enabled, speed) => {
        clearInterval(window.__nlScrollInterval);
        if (enabled) {
          window.__nlScrollInterval = setInterval(() => {
            window.scrollBy(0, speed * 0.8);
          }, 30);
        }
      },
      args: [on, spd],
    });
    toast(on ? '⬇️ Auto scroll ativado' : '⏹ Auto scroll parado', 'ok', E);
  });

  // ── Silenciar mídias ───────────────────────────────────────────
  E.muteVideos.addEventListener('click', async () => {
    const tab = await getActiveTab();
    if (!tab?.id) return;
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        const medias   = [...document.querySelectorAll('video,audio')];
        const allMuted = medias.length > 0 && medias.every(v => v.muted);
        medias.forEach(v => { v.muted = !allMuted; if (!allMuted) v.pause(); });
        return { count: medias.length, muted: !allMuted };
      },
    });
    const r = results?.[0]?.result;
    if (!r || r.count === 0) { toast('Nenhuma mídia encontrada', 'ok', E); return; }
    toast(`🔇 ${r.count} mídia(s) ${r.muted ? 'mutada(s)' : 'desmutada(s)'}`, 'ok', E);
  });

  // ── Ocultar imagens ────────────────────────────────────────────
  E.toggleImages.addEventListener('change', async () => {
    const on  = E.toggleImages.checked;
    const tab = await getActiveTab();
    if (!tab?.id) return;
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: (hide) => {
        const ID = 'nl-hide-imgs';
        if (hide) {
          if (document.getElementById(ID)) return;
          const s = document.createElement('style');
          s.id = ID;
          s.textContent = `img, picture, video { visibility: hidden !important; }`;
          document.head.appendChild(s);
        } else {
          document.getElementById(ID)?.remove();
        }
      },
      args: [on],
    });
    toast(on ? '🖼️ Imagens ocultadas' : '🖼️ Imagens restauradas', 'ok', E);
  });

  // ── Zoom de texto ──────────────────────────────────────────────
  const applyZoom = async () => {
    E.zoomVal.textContent = `${S.zoom}%`;
    const tab = await getActiveTab();
    if (!tab?.id) return;
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func:   (zoom) => { document.documentElement.style.fontSize = `${zoom}%`; },
      args:   [S.zoom],
    });
  };

  E.zoomIn.addEventListener('click', async () => {
    if (S.zoom < 200) { S.zoom = Math.min(200, S.zoom + 10); await applyZoom(); }
  });
  E.zoomOut.addEventListener('click', async () => {
    if (S.zoom > 60) { S.zoom = Math.max(60, S.zoom - 10); await applyZoom(); }
  });
  E.zoomReset.addEventListener('click', async () => {
    S.zoom = 100;
    await applyZoom();
    toast('📏 Zoom resetado', 'ok', E);
  });
}

// ══════════════════════════════════════════════════════════════════
// Pending requests (vindos do menu de contexto)
// ══════════════════════════════════════════════════════════════════
async function checkPending(E) {
  try {
    const { pendingRequest } = await chrome.storage.session.get(['pendingRequest']);
    if (!pendingRequest) return;
    if (Date.now() - pendingRequest.ts > 15_000) return;

    await chrome.storage.session.remove(['pendingRequest']);

    const labels = {
      summarize: '📄 Resumir',
      translate:  '🌐 Traduzir',
      explain:    '💡 Explicar',
    };

    const label = labels[pendingRequest.action] ?? '';
    const text  = pendingRequest.text ?? '';
    const msg   = `${label}:\n\n${text.substring(0, 3000)}`;

    addMsg('user', `${label}: "${text.substring(0, 80)}…"`, E);
    S.history.push({ role: 'user', content: msg });
    switchTab('chat');
    await aiRequest(E);
  } catch {
    // chrome.storage.session pode não estar disponível em todos os contextos
  }
}

// ══════════════════════════════════════════════════════════════════
// Modal helpers [FIX 4]
// ══════════════════════════════════════════════════════════════════
function openModal(el) {
  el.classList.remove('modal--hidden');
  el.setAttribute('aria-modal', 'true');
  // Foca o primeiro elemento interativo para acessibilidade
  el.querySelector('button')?.focus();
}

function closeModal(el) {
  el.classList.add('modal--hidden');
  el.removeAttribute('aria-modal');
}

// ══════════════════════════════════════════════════════════════════
// Utilitários
// ══════════════════════════════════════════════════════════════════
async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab ?? null;
}

async function sendToContent(action, extra = {}) {
  const tab = await getActiveTab();
  if (!tab?.id) return;
  try {
    await chrome.tabs.sendMessage(tab.id, { action, ...extra });
  } catch (_) {
    // Content script pode não estar injetado na página atual
  }
}

let _toastTimer = null;

function toast(msg, type = 'ok', E) {
  if (!E?.toast) return;
  const el = E.toast;
  el.textContent = msg;
  el.className   = `toast toast--show${type === 'err' ? ' toast--err' : ''}`;
  clearTimeout(_toastTimer);
  _toastTimer = setTimeout(() => el.classList.remove('toast--show'), 2600);
}

function escapeHtml(str) {
  return String(str ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
