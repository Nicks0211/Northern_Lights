/**
 * Northern Lights — Options Page Controller
 */
'use strict';

const DEFAULT_PROMPT = `Você é o Northern Lights, assistente de IA integrado ao navegador.
Seja conciso, útil e amigável. Responda sempre no idioma do usuário.
Pode resumir páginas, traduzir, explicar e ajudar com qualquer tarefa.`;

document.addEventListener('DOMContentLoaded', async () => {
  // Carrega configurações salvas
  const d = await chrome.storage.sync.get(['apiKey', 'model', 'sysPrompt']);

  document.getElementById('apiKey').value    = d.apiKey    ?? '';
  document.getElementById('model').value     = d.model     ?? 'claude-sonnet-4-6';
  document.getElementById('sysPrompt').value = d.sysPrompt ?? DEFAULT_PROMPT;

  // Toggle visibilidade da API key
  document.getElementById('toggleVis').addEventListener('click', () => {
    const inp   = document.getElementById('apiKey');
    const btn   = document.getElementById('toggleVis');
    const isPass = inp.type === 'password';
    inp.type     = isPass ? 'text' : 'password';
    btn.textContent = isPass ? '🙈' : '👁';
  });

  // Salvar
  document.getElementById('save').addEventListener('click', async () => {
    const key    = document.getElementById('apiKey').value.trim();
    const model  = document.getElementById('model').value;
    const prompt = document.getElementById('sysPrompt').value.trim();

    if (!key) {
      showStatus('⚠️ Insira uma API Key válida antes de salvar.', 'err');
      return;
    }

    if (!key.startsWith('sk-ant-')) {
      showStatus('❌ Formato inválido. A chave deve começar com sk-ant-', 'err');
      return;
    }

    await chrome.storage.sync.set({
      apiKey:    key,
      model:     model,
      sysPrompt: prompt || DEFAULT_PROMPT,
    });

    showStatus('✅ Configurações salvas com sucesso!', 'ok');
  });
});

function showStatus(msg, type) {
  const el = document.getElementById('status');
  el.textContent = msg;
  el.className   = type;
  setTimeout(() => { el.className = ''; el.style.display = 'none'; }, 3500);
}
