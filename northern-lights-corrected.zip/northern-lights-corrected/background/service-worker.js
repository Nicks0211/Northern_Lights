/**
 * Northern Lights — Background Service Worker
 * Gerencia menus de contexto, chamadas à API e comunicação entre scripts
 */
'use strict';

// ─── Instalação ────────────────────────────────────────────────────────────────
chrome.runtime.onInstalled.addListener(() => {
  // removeAll() garante que não há duplicatas em updates/reinstalações
  chrome.contextMenus.removeAll(() => {
    createContextMenus();
  });
  console.info('[NL] Northern Lights installed ✓');
});

function createContextMenus() {
  const menus = [
    { id: 'nl-summarize', title: '✨ Resumir com IA',   contexts: ['selection'] },
    { id: 'nl-translate', title: '🌐 Traduzir com IA',  contexts: ['selection'] },
    { id: 'nl-explain',   title: '💡 Explicar com IA',  contexts: ['selection'] },
    { id: 'nl-sep',       type: 'separator',            contexts: ['selection'] },
    { id: 'nl-unlock',    title: '🔓 Northern Lights: Alternar Desbloqueador', contexts: ['page'] },
  ];
  menus.forEach(m => chrome.contextMenus.create(m));
}

// ─── Menu de contexto ──────────────────────────────────────────────────────────
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (!tab?.id) return;

  if (info.menuItemId === 'nl-unlock') {
    const { unlockerEnabled } = await chrome.storage.sync.get(['unlockerEnabled']);
    const next = !unlockerEnabled;
    await chrome.storage.sync.set({ unlockerEnabled: next });
    safeSendMessage(tab.id, { action: next ? 'ENABLE_UNLOCKER' : 'DISABLE_UNLOCKER' });
    return;
  }

  const actionMap = {
    'nl-summarize': 'summarize',
    'nl-translate': 'translate',
    'nl-explain':   'explain',
  };

  const action = actionMap[info.menuItemId];
  if (!action) return;

  await chrome.storage.session.set({
    pendingRequest: { text: info.selectionText, action, ts: Date.now() }
  }).catch(() => {});

  chrome.action.openPopup().catch(() => {
    // openPopup() falha sem gesto do usuário no MV3 — abre popup numa janela dedicada
    chrome.windows.create({
      url:    chrome.runtime.getURL('popup/popup.html'),
      type:   'popup',
      width:  420,
      height: 600,
    });
  });
});

// ─── Mensagens do popup / content scripts ──────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.action === 'AI_REQUEST') {
    callAnthropicAPI(msg)
      .then(result => sendResponse({ ok: true, result }))
      .catch(err   => sendResponse({ ok: false, error: err.message }));
    return true; // mantém canal assíncrono aberto
  }
});

// ─── Anthropic API ─────────────────────────────────────────────────────────────
async function callAnthropicAPI({ apiKey, model, systemPrompt, messages }) {
  if (!apiKey)           throw new Error('API Key não configurada.');
  if (!messages?.length) throw new Error('Nenhuma mensagem fornecida.');

  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type':      'application/json',
      'x-api-key':         apiKey,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model:      model ?? 'claude-sonnet-4-6',
      max_tokens: 1024,
      system:     systemPrompt ?? 'Você é o Northern Lights, assistente de IA do navegador. Seja conciso e útil.',
      messages,
    }),
  });

  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error?.message ?? `HTTP ${res.status}`);
  }

  const data = await res.json();
  return data.content?.[0]?.text ?? '';
}

// ─── Utilitários ───────────────────────────────────────────────────────────────
async function safeSendMessage(tabId, msg) {
  try { await chrome.tabs.sendMessage(tabId, msg); } catch (_) {}
}
