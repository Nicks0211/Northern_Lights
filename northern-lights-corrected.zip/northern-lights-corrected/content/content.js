/**
 * Northern Lights — Content Script (Isolated World)
 * Ponte entre a extensão e o unlocker no contexto da página
 */
'use strict';

// ─── Bootstrap: sincroniza estado do storage com o MAIN world ─────────────────
(async function bootstrap() {
  await waitForUnlocker();
  const { unlockerEnabled } = await chrome.storage.sync.get(['unlockerEnabled']);
  if (unlockerEnabled) sendToMain('ENABLE');
})();

function waitForUnlocker(timeout = 3000) {
  return new Promise((resolve) => {
    const handler = (evt) => {
      if (evt.source !== window || evt.data?.nl !== 'READY') return;
      window.removeEventListener('message', handler);
      clearInterval(retryInterval);
      resolve();
    };
    window.addEventListener('message', handler);

    // Retry INIT a cada 100ms: unlocker.js pode ainda não ter registrado o listener
    let elapsed = 0;
    const retryInterval = setInterval(() => {
      elapsed += 100;
      window.postMessage({ nl: 'INIT' }, '*');
      if (elapsed >= timeout) {
        clearInterval(retryInterval);
        window.removeEventListener('message', handler);
        resolve(); // timeout — continua mesmo sem confirmação
      }
    }, 100);

    // Dispara imediatamente também
    window.postMessage({ nl: 'INIT' }, '*');
  });
}

function sendToMain(cmd) {
  window.postMessage({ nl: cmd }, '*');
}

// ─── Listener de mensagens vindas do popup / background ───────────────────────
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  const respond = (data) => { try { sendResponse(data); } catch (_) {} };

  switch (msg.action) {

    case 'ENABLE_UNLOCKER':
      sendToMain('ENABLE');
      respond({ ok: true });
      break;

    case 'DISABLE_UNLOCKER':
      sendToMain('DISABLE');
      respond({ ok: true });
      break;

    case 'GET_PAGE_INFO':
      respond({
        title:        document.title,
        url:          location.href,
        text:         document.body?.innerText?.substring(0, 6000) ?? '',
        selectedText: window.getSelection()?.toString() ?? '',
        wordCount:    countWords(document.body?.innerText ?? ''),
      });
      break;

    case 'GET_PAGE_TEXT':
      respond({ text: document.body?.innerText ?? '' });
      break;

    case 'GET_SELECTED_TEXT':
      respond({ text: window.getSelection()?.toString() ?? '' });
      break;

    case 'SCROLL_TO_TOP':
      window.scrollTo({ top: 0, behavior: 'smooth' });
      respond({ ok: true });
      break;

    case 'SCROLL_TO_BOTTOM':
      window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
      respond({ ok: true });
      break;

    case 'HIGHLIGHT_TEXT':
      highlightText(msg.text);
      respond({ ok: true });
      break;

    case 'CLEAR_HIGHLIGHTS':
      clearHighlights();
      respond({ ok: true });
      break;

    default:
      respond({ ok: false, error: 'Unknown action' });
  }

  return true;
});

// ─── Helpers ──────────────────────────────────────────────────────────────────
function countWords(text) {
  return text.split(/\s+/).filter(w => w.length > 0).length;
}

function highlightText(query) {
  if (!query) return;
  clearHighlights();

  const walker = document.createTreeWalker(
    document.body,
    NodeFilter.SHOW_TEXT,
    {
      acceptNode: n =>
        n.parentElement?.closest('script,style,noscript')
          ? NodeFilter.FILTER_REJECT
          : NodeFilter.FILTER_ACCEPT
    }
  );

  const regex = new RegExp(escapeRegex(query), 'gi');
  const nodes = [];

  while (walker.nextNode()) {
    if (regex.test(walker.currentNode.nodeValue)) nodes.push(walker.currentNode);
    regex.lastIndex = 0;
  }

  nodes.forEach(node => {
    const frag    = document.createDocumentFragment();
    const parts   = node.nodeValue.split(regex);
    const matches = node.nodeValue.match(regex) ?? [];

    parts.forEach((part, i) => {
      frag.appendChild(document.createTextNode(part));
      if (matches[i]) {
        const mark = document.createElement('mark');
        mark.className   = 'nl-highlight';
        mark.textContent = matches[i];
        frag.appendChild(mark);
      }
    });

    node.parentNode?.replaceChild(frag, node);
  });

  document.querySelector('.nl-highlight')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

function clearHighlights() {
  document.querySelectorAll('.nl-highlight').forEach(mark => {
    mark.replaceWith(document.createTextNode(mark.textContent));
  });
}

function escapeRegex(str) {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}
