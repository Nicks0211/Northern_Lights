/**
 * Northern Lights — Copy/Paste Unlocker
 * MAIN world: acessa e sobrescreve o JavaScript nativo da página
 * Requer Chrome 111+ para world: "MAIN" em content_scripts
 */
(function () {
  'use strict';

  let _enabled  = false;
  let _interval = null;
  let _observer = null;

  // Referências originais — salvas ANTES de qualquer override
  const _origAddEventListener = EventTarget.prototype.addEventListener;

  // Eventos que sites usam para bloquear cópia
  const COPY_EVENTS = new Set([
    'copy', 'cut', 'paste',
    'selectstart', 'select',
    'contextmenu',
    'dragstart', 'drag',
  ]);

  // ─── Patch addEventListener ──────────────────────────────────────────────────
  function patchAddEventListener() {
    EventTarget.prototype.addEventListener = function (type, handler, options) {
      if (_enabled && COPY_EVENTS.has(type) && typeof handler === 'function') {
        const wrapped = function (event) {
          const origPD  = event.preventDefault.bind(event);
          const origSP  = event.stopPropagation.bind(event);
          const origSIP = event.stopImmediatePropagation.bind(event);
          event.preventDefault          = () => {};
          event.stopPropagation         = () => {};
          event.stopImmediatePropagation = () => {};
          try   { handler.call(this, event); }
          finally {
            event.preventDefault          = origPD;
            event.stopPropagation         = origSP;
            event.stopImmediatePropagation = origSIP;
          }
        };
        return _origAddEventListener.call(this, type, wrapped, options);
      }
      return _origAddEventListener.call(this, type, handler, options);
    };
  }

  function restoreAddEventListener() {
    EventTarget.prototype.addEventListener = _origAddEventListener;
  }

  // ─── Limpeza de handlers inline e CSS ───────────────────────────────────────
  function clearInlineHandlers() {
    const targets = [document, document.documentElement, document.body].filter(Boolean);
    targets.forEach(el => {
      el.oncopy        = null;
      el.oncut         = null;
      el.onpaste       = null;
      el.onselectstart = null;
      el.oncontextmenu = null;
      el.ondragstart   = null;
    });
  }

  function injectUnlockerCSS() {
    if (document.getElementById('nl-unlocker-css')) return;
    const s = document.createElement('style');
    s.id = 'nl-unlocker-css';
    s.textContent = `
      *, *::before, *::after {
        -webkit-user-select: text !important;
           -moz-user-select: text !important;
                user-select: text !important;
      }
    `;
    (document.head || document.documentElement).appendChild(s);
  }

  function removeUnlockerCSS() {
    document.getElementById('nl-unlocker-css')?.remove();
  }

  // ─── Badge visual de status ──────────────────────────────────────────────────
  function showBadge() {
    if (document.getElementById('nl-unlocker-badge')) return;
    const badge = document.createElement('div');
    badge.id          = 'nl-unlocker-badge';
    badge.className   = 'nl-unlocker-badge';
    badge.textContent = '🔓 Northern Lights: desbloqueado';
    (document.body || document.documentElement).appendChild(badge);
  }

  function removeBadge() {
    document.getElementById('nl-unlocker-badge')?.remove();
  }

  // ─── Observador de mutações (lida com SPAs e conteúdo dinâmico) ─────────────
  function startObserver() {
    _observer = new MutationObserver(() => {
      if (_enabled) clearInlineHandlers();
    });
    _observer.observe(document, { childList: true, subtree: true, attributes: true });
  }

  function stopObserver() {
    _observer?.disconnect();
    _observer = null;
  }

  // ─── Ativar / Desativar ──────────────────────────────────────────────────────
  function enable() {
    _enabled = true;
    patchAddEventListener();
    clearInlineHandlers();
    injectUnlockerCSS();
    startObserver();
    showBadge();
    _interval = setInterval(() => {
      if (!_enabled) return;
      clearInlineHandlers();
    }, 1500);
  }

  function disable() {
    _enabled = false;
    clearInterval(_interval);
    _interval = null;
    stopObserver();
    restoreAddEventListener();
    removeUnlockerCSS();
    removeBadge();
  }

  // ─── Canal de mensagens com content.js (ISOLATED world) ─────────────────────
  window.addEventListener('message', (evt) => {
    if (evt.source !== window || !evt.data?.nl) return;
    switch (evt.data.nl) {
      case 'ENABLE':  enable();  break;
      case 'DISABLE': disable(); break;
      case 'PING':
        window.postMessage({ nl: 'PONG', enabled: _enabled }, '*');
        break;
      case 'INIT':
        window.postMessage({ nl: 'READY' }, '*');
        break;
    }
  });

})();
